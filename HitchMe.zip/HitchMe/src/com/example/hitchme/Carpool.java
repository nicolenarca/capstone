package com.example.hitchme;

import android.app.Activity;
import android.os.Bundle;

public class Carpool extends Activity {

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		this.setContentView(R.layout.carpool);
		
	}

}
