package com.example.hitchme;

import java.util.ArrayList;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.AlertDialog.Builder;
import android.content.Intent;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;


public class Reg extends Activity implements OnClickListener {
	
	EditText license, plate, type, model;
	Button btnSubmit;
	Mydatabase database;
	ArrayList<User> list = new ArrayList<User>();
	//Uri uri;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		this.setContentView(R.layout.reg_too);
		
		license = (EditText) this.findViewById(R.id.editText1);
		plate = (EditText) this.findViewById(R.id.editText2);
		type = (EditText) this.findViewById(R.id.editText3);
		model = (EditText) this.findViewById(R.id.editText4);
		
		btnSubmit = (Button) this.findViewById(R.id.button1);
		database = new Mydatabase(this);
	
		btnSubmit.setOnClickListener(this);
	
	}

	@Override
	public void onClick(View arg0) {
		// TODO Auto-generated method stub
		
			String lname = getIntent().getExtras().getString("lastname");
			String fname = getIntent().getExtras().getString("firstname");
			String username = getIntent().getExtras().getString("username");
			String password = getIntent().getExtras().getString("password");
			String address = getIntent().getExtras().getString("address");
			String contact = getIntent().getExtras().getString("contact");
			String alternateno = getIntent().getExtras().getString("alternateno");
			String sex = getIntent().getExtras().getString("sex");
			String licenseno = this.license.getText().toString();
			String plateno = this.plate.getText().toString();
			String type = this.type.getText().toString();
			String model = this.model.getText().toString();
		
			this.database.addReg(lname, fname, username, password, address, contact, alternateno, sex, licenseno, plateno, type, model);
			this.list.add(new User(lname, fname, username, password, address, contact, alternateno, sex));
			
			this.license.setText("");
			this.plate.setText("");
			this.type.setText("");
			this.model.setText("");
		
			Toast.makeText(this, "Successful Account!", Toast.LENGTH_LONG).show();
			
			Intent intent = new Intent(this, UserLogin.class);
			this.startActivity(intent);
		
	}


}
