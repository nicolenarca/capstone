package com.example.hitchme;

import java.util.ArrayList;

import android.app.Activity;
import android.os.Bundle;
import android.widget.ListView;
import android.widget.TextView;

public class ViewSubs extends Activity {
	
	ListView lv;
	ArrayList<Subscribe> subs = new ArrayList<Subscribe>();
	SubsAdapter adapter;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		this.setContentView(R.layout.viewsub);
		
		lv = (ListView) this.findViewById(R.id.listView1);
		adapter = new SubsAdapter(this,subs);
		
		lv.setAdapter(adapter);
	
	}
	

}
