package com.example.hitchme;

import java.util.ArrayList;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

public class SubsAdapter extends BaseAdapter {
	
	Context context;
	ArrayList<Subscribe> subs = new ArrayList<Subscribe>();
	LayoutInflater inflater;
	
	

	public SubsAdapter(Context context, ArrayList<Subscribe> subs) {
		super();
		this.context = context;
		this.subs = subs;
		this.inflater = LayoutInflater.from(context);
	}

	@Override
	public int getCount() {
		// TODO Auto-generated method stub
		return subs.size();
	}

	@Override
	public Object getItem(int arg0) {
		// TODO Auto-generated method stub
		return subs.get(arg0);
	}

	@Override
	public long getItemId(int arg0) {
		// TODO Auto-generated method stub
		return arg0;
	}

	@Override
	public View getView(int arg0, View arg1, ViewGroup arg2) {
		// TODO Auto-generated method stub
		
		SubsHandler handler = null;
		if(arg1==null)
		{
			arg1 = inflater.inflate(R.layout.subslay, null);
			handler = new SubsHandler();
			handler.xxx = (TextView) arg1.findViewById(R.id.textView1);
			handler.xx = (TextView) arg1.findViewById(R.id.textView2);
			handler.x = (TextView) arg1.findViewById(R.id.textView3);
			arg1.setTag(handler);
		}else handler = (SubsHandler) arg1.getTag();
		
		handler.xxx.setText(subs.get(arg0).getSname1());
		handler.xx.setText(subs.get(arg0).getAmt2());
		handler.x.setText(subs.get(arg0).getAmt3());
		
		return arg1;
	}
	
	static class SubsHandler{
		TextView xxx, xx, x;
	}

}
