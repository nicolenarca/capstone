package com.example.hitchme;

import java.util.ArrayList;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

public class Subscription extends Activity{
	
	RadioGroup km;
	Button s;
	RadioButton selected_km;
	RadioButton s1,s2,s3;
	TextView a1,a2,a3;
	String k;
	int amt, index=0;
	ArrayList<Subscribe> subs = new ArrayList<Subscribe>();

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		this.setContentView(R.layout.subscribe);
		
		
		
		s = (Button) this.findViewById(R.id.button1);
		km = (RadioGroup) this.findViewById(R.id.radioGroup1);
		s1 = (RadioButton) this.findViewById(R.id.radio0);
		s2 = (RadioButton) this.findViewById(R.id.radio1);
		s3 = (RadioButton) this.findViewById(R.id.radio2);
		a1 = (TextView) this.findViewById(R.id.textView2);
		a2 = (TextView) this.findViewById(R.id.textView3);
		a3 = (TextView) this.findViewById(R.id.textView4);
		
		
		
			/*String sname1 = getIntent().getExtras().getString("sname1").toString();
			String kilo1 =  getIntent().getExtras().getString("kilo1").toString();
			String amt1 =  getIntent().getExtras().getString("amt1").toString();
			String sname2 = getIntent().getExtras().getString("sname2").toString();
			String kilo2 =  getIntent().getExtras().getString("kilo2").toString();
			String amt2 =  getIntent().getExtras().getString("amt2").toString();
			String sname3 = getIntent().getExtras().getString("sname3").toString();
			String kilo3 =  getIntent().getExtras().getString("kilo3").toString();
			String amt3 =  getIntent().getExtras().getString("amt3").toString();*/
		
		/*int index = subs.size() - 1;
			
			
		s1.setText(subs.get(index).getSname1()+"( "+subs.get(index).getKilo1()+" KILOMETERS)");
		a1.setText("Php "+subs.get(index).getAmt1());
		s2.setText(subs.get(index).getSname2()+"( "+subs.get(index).getKilo2()+" KILOMETERS)");
		a2.setText("Php "+subs.get(index).getAmt2());
		s3.setText(subs.get(index).getSname3()+"( "+subs.get(index).getKilo3()+" KILOMETERS)");
		a3.setText("Php "+subs.get(index).getAmt3());
		*/
			
		
	}


}
