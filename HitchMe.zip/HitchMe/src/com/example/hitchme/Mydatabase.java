package com.example.hitchme;


import java.util.ArrayList;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteDatabase.CursorFactory;
import android.database.sqlite.SQLiteOpenHelper;

public class Mydatabase extends SQLiteOpenHelper {
	
	Context context;
	final static String DATABASE="hitchme_db";
	final static String TABLE_USER="tbl_user";
	final static String TABLE_SUB="tbl_subscription";

	public Mydatabase(Context context) {
		super(context, DATABASE, null, 1);
		// TODO Auto-generated constructor stub
	}
	
	
	public long addReg(String lastname, String firstname, String username, String password,String address, String contactno, String alternateno, String sex, String licenseno, String plateno, String type, String model){
		
		long id = 0;
		
		
		SQLiteDatabase db = this.getWritableDatabase();
		ContentValues cv = new ContentValues();
		cv.put("lastname", lastname);
 		cv.put("firstname", firstname);
		cv.put("username", username);
		cv.put("password", password);
		cv.put("address", address);
		cv.put("contactno", contactno);
		cv.put("alternateno", alternateno);
		cv.put("sex", sex);
		cv.put("licenseno", licenseno);
		cv.put("plateno", plateno);
		cv.put("type", type);
		cv.put("model", model);
		
		id=db.insert(TABLE_USER, null, cv);
		db.close();
		
		return id;
	}
	public boolean isUsernameAndPassword(String username, String password){
		
		String u="", p="";
		Boolean q=false;
		SQLiteDatabase db = this.getReadableDatabase();
		
		
		Cursor cursor = db.query(TABLE_USER, null, null, null, null, null, "id");
		
		
		for(cursor.moveToFirst(); !cursor.isAfterLast(); cursor.moveToNext())
		{
			 u = cursor.getString(cursor.getColumnIndex("username"));
			 p = cursor.getString(cursor.getColumnIndex("password"));
			 if(u.equals(username) && p.equals(password))
			 {
				 q=true;
				 cursor.isClosed();
			 }
		}
		
		db.close();
		
		return q;
	}
	/*public void setStat(String username, String password, String s)
	{
		SQLiteDatabase db = this.getWritableDatabase();
		Cursor cursor = db.query(TABLE_USER, null, null, null, null, null, "id");
		ArrayList<String> user = new ArrayList<String>();
		ContentValues cv = new ContentValues();
		
		for(cursor.moveToFirst(); !cursor.isAfterLast(); cursor.moveToNext())
		{
			String u = cursor.getString(cursor.getColumnIndex("username"));
			String p = cursor.getString(cursor.getColumnIndex("password"));
		
			if(u.equals(username) && p.equals(password))
			{
				user = getUser(username,password);
				cv.put("lastname", user.get(0).toString());
				cv.put("firstname", user.get(1).toString());
				cv.put("username", username);
				cv.put("password", password);
				cv.put("address", user.get(2).toString());
				cv.put("contactno", user.get(3).toString());
				cv.put("alternateno", user.get(4).toString());
				cv.put("sex", user.get(5).toString());
				
				db.update(TABLE_USER, cv, "status=?", new String[]{s});
				
				cursor.close();
			}
			
			db.close();
		}
	}
	public String getStat(String username, String password)
	{
			
		SQLiteDatabase db = this.getWritableDatabase();
		Cursor cursor = db.query(TABLE_USER, null, null, null, null, null, "id");
		String status="";
		
		for(cursor.moveToFirst(); !cursor.isAfterLast(); cursor.moveToNext())
		{
			 String u = cursor.getString(cursor.getColumnIndex("username"));
			 String p = cursor.getString(cursor.getColumnIndex("password"));
			 String s = cursor.getString(cursor.getColumnIndex("status"));
			 
			 if(u.equals(username) && p.equals(password)){
				 
				 status = s;
			 }
		
		}
		return status;
	
	}*/
	public ArrayList<String> getUser(String username, String password)
	{
		SQLiteDatabase db = this.getWritableDatabase();
		ArrayList<String> list = new ArrayList<String>();
		Cursor c = db.query(TABLE_USER, null, null, null, null, null, "id");
		
		for(c.moveToFirst(); !c.isAfterLast(); c.moveToNext())
		{
			String l = c.getString(c.getColumnIndex("lastname"));
			String f = c.getString(c.getColumnIndex("firstname"));
			String u = c.getString(c.getColumnIndex("username"));
			String p = c.getString(c.getColumnIndex("password"));
			String adr = c.getString(c.getColumnIndex("address"));
			String con = c.getString(c.getColumnIndex("contactno"));
			String al = c.getString(c.getColumnIndex("alternateno"));
			String sex = c.getString(c.getColumnIndex("sex"));
			
			if(username.equals(u) && password.equals(p))
			{
				
				list.add(l);
				list.add(f);
				list.add(adr);
				list.add(con);
				list.add(al);
				list.add(sex);
				
				c.isAfterLast();
			}
		}
		
		db.close();
		
		return list;
		
	}
	
	
	
	public ArrayList<User> getList()
	{
		ArrayList<User> list = new ArrayList<User>();
		SQLiteDatabase db = this.getReadableDatabase();
		Cursor cursor = db.query(TABLE_USER, null, null, null, null, null, "id");
		
		for(cursor.moveToFirst(); !cursor.isAfterLast(); cursor.moveToNext())
		{
			
			String lastname=cursor.getString(cursor.getColumnIndex("lastname"));
			String firstname=cursor.getString(cursor.getColumnIndex("firstname"));
			String username=cursor.getString(cursor.getColumnIndex("username"));
			String password=cursor.getString(cursor.getColumnIndex("password"));
			String address=cursor.getString(cursor.getColumnIndex("address"));
			String contact=cursor.getString(cursor.getColumnIndex("contactno"));
			String alternate=cursor.getString(cursor.getColumnIndex("alternateno"));
			String sex=cursor.getString(cursor.getColumnIndex("sex"));
			
			list.add(new User(lastname, firstname, username, password, address, contact, alternate, sex));
		}
		
		db.close();
		
		return list;
	}
	
	public int deleteUser(String lname, String fname, String sex)
	{
		int id= 0;
		
		SQLiteDatabase db = this.getWritableDatabase();
		id=db.delete(TABLE_USER, "lastname=? AND firstname=? AND sex=?", new String[]{lname, fname,sex});
		db.close();
		return id;
	}
	
	
	@Override
	public void onCreate(SQLiteDatabase arg0) {
		// TODO Auto-generated method stub
		
		String mysql="CREATE TABLE "+TABLE_USER+"(id integer primary key autoincrement, lastname varchar(30), firstname varchar(30), username varchar(30), password varchar(8), address varchar(30), contactno varchar(11), alternateno varchar(11), sex varchar(10), licenseno varchar(30), plateno varchar(30), type varchar(20), model varchar(20))";
		arg0.execSQL(mysql);
		
		

	}

	@Override
	public void onUpgrade(SQLiteDatabase arg0, int arg1, int arg2) {
		// TODO Auto-generated method stub
		
		String newMysql = "ALTER TABLE "+TABLE_SUB+"(id integer primary key autoincrement, status varchar(1))";
		arg0.execSQL(newMysql);
		onCreate(arg0);
		
	}

}
