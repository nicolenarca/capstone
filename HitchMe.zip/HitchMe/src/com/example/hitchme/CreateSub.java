package com.example.hitchme;

import java.util.ArrayList;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.AlertDialog.Builder;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

public class CreateSub extends Activity implements OnClickListener, android.content.DialogInterface.OnClickListener{
	
	Button create, view, mk;
	EditText name, name2, name3, kilo, kilo2, kilo3, amt, amt2, amt3;
	ArrayList<Subscribe> subs = new ArrayList<Subscribe>();
	SubsAdapter adapter;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		this.setContentView(R.layout.sub_menu);
		
		
		create = (Button) this.findViewById(R.id.button1);
		view = (Button) this.findViewById(R.id.button2);
		mk = (Button) this.findViewById(R.id.button4);
		
		adapter = new SubsAdapter(this,subs);
		
		this.create.setOnClickListener(this);
		this.view.setOnClickListener(this);
		this.mk.setOnClickListener(this);
		
	}
	
	

	@Override
	public void onClick(View arg0) {
		// TODO Auto-generated method stub
		
		switch(arg0.getId())
		{
		case R.id.button1: 
				name = new EditText(this);
				kilo = new EditText(this);
				amt = new EditText(this);
				name2 = new EditText(this);
				kilo2 = new EditText(this);
				amt2 = new EditText(this);
				name3 = new EditText(this);
				kilo3 = new EditText(this);
				amt3 = new EditText(this);
				
				name.setHint("Enter Subscription Name1");
				name2.setHint("Enter Subscription Name2");
				name3.setHint("Enter Subscription Name3");
				kilo.setHint("Enter Kilometer1");
				kilo2.setHint("Enter Kilometer2");
				kilo3.setHint("Enter Kilometer3");
				amt.setHint("Enter Amount1");
				amt2.setHint("Enter Amount2");
				amt3.setHint("Enter Amount3");
				
				LinearLayout layout = new LinearLayout(this);
				layout.setOrientation(LinearLayout.VERTICAL);
				layout.addView(name);
				layout.addView(kilo);
				layout.addView(amt);
				layout.addView(name2);
				layout.addView(kilo2);
				layout.addView(amt2);
				layout.addView(name3);
				layout.addView(kilo3);
				layout.addView(amt3);
				
				AlertDialog.Builder b = new AlertDialog.Builder(this);
				b.setTitle("Create Subscription");
				b.setView(layout);
				b.setPositiveButton("DONE", this);
				b.setNegativeButton("CANCEL", this);
				
				AlertDialog d = b.create();
				d.show();
				break;
				
		case R.id.button2: Intent intent = new Intent(this, ViewSubs.class);
							this.startActivity(intent);
		
		
		}
		
		
		
	}



	@Override
	public void onClick(DialogInterface dialog, int which) {
		// TODO Auto-generated method stub
		
		
		
		switch(which)
		{
		case DialogInterface.BUTTON_POSITIVE:
			
			String n1 = this.name.getText().toString();
			String n2 = this.name2.getText().toString();
			String n3 = this.name3.getText().toString();
			String k1 = this.kilo.getText().toString();
			String k2 = this.kilo2.getText().toString();
			String k3 = this.kilo3.getText().toString();
			String a1 = this.amt.getText().toString();
			String a2 = this.amt2.getText().toString();
			String a3 = this.amt3.getText().toString();
			
			subs.add(new Subscribe(n1, k1, a1, n2, k2, a2, n3, k3, a3));
			adapter.notifyDataSetChanged();
			
			/*Intent intent = new Intent(this, Subscription.class);
			/*intent.putExtra("sname1", n1);
			intent.putExtra("sname2", n2);
			intent.putExtra("sname3", n3);
			intent.putExtra("kilo1", k1);
			intent.putExtra("kilo2", k2);
			intent.putExtra("kilo3", k3);
			intent.putExtra("amt1", a1);
			intent.putExtra("amt2", a2);
			intent.putExtra("amt3", a3);
			this.startActivity(intent);*/ 
			
			break;
		case DialogInterface.BUTTON_NEGATIVE: dialog.dismiss();
		}
		
		
		
	}


}
