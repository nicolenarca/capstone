package com.example.hitchme;

public class Subscribe {
	
	String sname1, kilo1, amt1, sname2, kilo2, amt2, sname3, kilo3, amt3;

	public Subscribe(String sname1, String kilo1, String amt1, String sname2,
			String kilo2, String amt2, String sname3, String kilo3, String amt3) {
		super();
		this.sname1 = sname1;
		this.kilo1 = kilo1;
		this.amt1 = amt1;
		this.sname2 = sname2;
		this.kilo2 = kilo2;
		this.amt2 = amt2;
		this.sname3 = sname3;
		this.kilo3 = kilo3;
		this.amt3 = amt3;
	}

	public String getSname1() {
		return sname1;
	}

	public void setSname1(String sname1) {
		this.sname1 = sname1;
	}

	public String getKilo1() {
		return kilo1;
	}

	public void setKilo1(String kilo1) {
		this.kilo1 = kilo1;
	}

	public String getAmt1() {
		return amt1;
	}

	public void setAmt1(String amt1) {
		this.amt1 = amt1;
	}

	public String getSname2() {
		return sname2;
	}

	public void setSname2(String sname2) {
		this.sname2 = sname2;
	}

	public String getKilo2() {
		return kilo2;
	}

	public void setKilo2(String kilo2) {
		this.kilo2 = kilo2;
	}

	public String getAmt2() {
		return amt2;
	}

	public void setAmt2(String amt2) {
		this.amt2 = amt2;
	}

	public String getSname3() {
		return sname3;
	}

	public void setSname3(String sname3) {
		this.sname3 = sname3;
	}

	public String getKilo3() {
		return kilo3;
	}

	public void setKilo3(String kilo3) {
		this.kilo3 = kilo3;
	}

	public String getAmt3() {
		return amt3;
	}

	public void setAmt3(String amt3) {
		this.amt3 = amt3;
	}
	
	
	

}
