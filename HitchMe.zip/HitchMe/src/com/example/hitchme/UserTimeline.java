package com.example.hitchme;

import java.util.ArrayList;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

public class UserTimeline extends Activity implements OnClickListener {
	
	ImageView profile;
	TextView lastname, firstname, username, password, contact, alternate, address, sex;
	Button saveChanges;
	ArrayList<String> list = new ArrayList<String>();
	Mydatabase database;
	Uri uri;
	ArrayList<Uri> im = new ArrayList<Uri>();

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		this.setContentView(R.layout.user_timeline);
		
		profile = (ImageView) this.findViewById(R.id.imageView1);
		
		lastname = (TextView) this.findViewById(R.id.textView3);
		firstname = (TextView) this.findViewById(R.id.textView5);
		username = (TextView) this.findViewById(R.id.textView7);
		password = (TextView) this.findViewById(R.id.textView9);
		address = (TextView) this.findViewById(R.id.textView11);
		contact = (TextView) this.findViewById(R.id.textView13);
		alternate = (TextView) this.findViewById(R.id.textView15);
		sex = (TextView) this.findViewById(R.id.textView17);
		saveChanges = (Button) this.findViewById(R.id.button1);
		
		database = new Mydatabase(this);
		
		String u = getIntent().getExtras().getString("username");
		String p = getIntent().getExtras().getString("password");
		
		list = this.database.getUser(u, p);
		
		this.lastname.setText(list.get(0).toString());
		this.firstname.setText(list.get(1).toString());
		this.username.setText(u);
		this.password.setText(p);
		this.address.setText(list.get(2).toString());
		this.contact.setText(list.get(3).toString());
		this.alternate.setText(list.get(4).toString());
		this.sex.setText(list.get(5).toString());
		
		this.profile.setOnClickListener(this);
		this.saveChanges.setOnClickListener(this);
		
		
	}
	

	@Override
	public void onClick(View arg0) {
		// TODO Auto-generated method stub
		
		Intent intent = new Intent(Intent.ACTION_PICK, android.provider.MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
		intent.putExtra(MediaStore.EXTRA_OUTPUT, uri);
		this.startActivityForResult(intent, 100);
		
	}

	@Override
	protected void onActivityResult(int requestCode, int resultCode, Intent data) {
		// TODO Auto-generated method stub
		super.onActivityResult(requestCode, resultCode, data);
		
		uri = data.getData();
		this.profile.setImageURI(uri);
		
	}

	
	

}
