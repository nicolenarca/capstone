package com.example.hitchme;

import java.util.ArrayList;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Toast;

public class Registration extends Activity implements OnClickListener {
	
	EditText lastname, firstname, username, password, address, contact, alternateno;
	RadioGroup sex;
	Button next;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		this.setContentView(R.layout.register);
		
		this.lastname=(EditText) this.findViewById(R.id.editText1);
		this.firstname=(EditText) this.findViewById(R.id.editText2);
		this.username=(EditText) this.findViewById(R.id.editText3);
		this.password=(EditText) this.findViewById(R.id.editText4);
		this.address=(EditText) this.findViewById(R.id.editText5);
		this.contact=(EditText) this.findViewById(R.id.editText6);
		this.alternateno=(EditText) this.findViewById(R.id.editText7);
		this.sex=(RadioGroup) this.findViewById(R.id.radioGroup1);
		this.next=(Button) this.findViewById(R.id.button1);
	
	
		next.setOnClickListener(this);
			
	}

	@Override
	public void onClick(View v) {
		String lname = this.lastname.getText().toString();
		String fname = this.firstname.getText().toString();
		String username =this.username.getText().toString();
		String password = this.password.getText().toString();
		String address = this.address.getText().toString();
		String contact = this.contact.getText().toString();
		String alternateno = this.alternateno.getText().toString();
		
		int sexid = this.sex.getCheckedRadioButtonId();
		RadioButton selected_button = (RadioButton) this.findViewById(sexid);
		String sel_sex = selected_button.getText().toString();
		
		
		if(lname.equals("") || fname.equals("") || username.equals("") || password.equals("") || address.equals("") || sel_sex.equals("") || contact.equals("") || alternateno.equals(""))
		{
			Toast.makeText(this, "Please fill all fields", Toast.LENGTH_LONG).show();
		}
		else
		{
		Intent driver = new Intent(this, Reg.class);
		driver.putExtra("lastname", lname)
			  .putExtra("firstname", fname)
			  .putExtra("username", username)
			  .putExtra("password", password)
			  .putExtra("address", address)
			  .putExtra("contact", contact)
			  .putExtra("sex", sel_sex)
			  .putExtra("alternateno", alternateno);
			  this.startActivity(driver);
		}
		
	}


}
