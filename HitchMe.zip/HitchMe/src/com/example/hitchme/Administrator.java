package com.example.hitchme;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.TextView;

public class Administrator extends Activity implements OnClickListener {
	
	TextView viewUsers, sub;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		this.setContentView(R.layout.admin_menu);
		
		viewUsers = (TextView) this.findViewById(R.id.textView2);
		sub = (TextView) this.findViewById(R.id.textView3);
		
		this.viewUsers.setOnClickListener(this);
		this.sub.setOnClickListener(this);
		
		
		
	}

	@Override
	public void onClick(View v) {
		// TODO Auto-generated method stub
		
		Intent intent;
		
		switch(v.getId())
		{
		case R.id.textView2: intent = new Intent(this, AdminView.class);
							 this.startActivity(intent);
							 break;
		case R.id.textView3: intent = new Intent(this, CreateSub.class);
							 this.startActivity(intent);
							 break;
		}
		
		
		
	}
	
	

}
