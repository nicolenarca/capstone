package com.example.hitchme;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.AlertDialog.Builder;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Toast;

public class Ridesharing extends Activity implements OnClickListener {
	
	Button hitch, carpool;
	

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		this.setContentView(R.layout.service_layout);
		
		hitch = (Button) this.findViewById(R.id.button1);
		carpool = (Button) this.findViewById(R.id.button2);
		
		this.hitch.setOnClickListener(this);
		this.carpool.setOnClickListener(this);
	}

	@Override
	public void onClick(View v) {
		// TODO Auto-generated method stub
		
		switch(v.getId()){
		case R.id.button1:
			Intent intent = new Intent(this, Hitch.class);
			this.startActivity(intent);
			break;
		case R.id.button2:
			Intent intent2 = new Intent(this, Carpool.class);
			this.startActivity(intent2);
		}
	}


}
