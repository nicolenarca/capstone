package com.example.hitchme;

import java.util.ArrayList;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.AlertDialog.Builder;
import android.os.Bundle;
import android.view.ContextMenu;
import android.view.ContextMenu.ContextMenuInfo;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.AdapterView.AdapterContextMenuInfo;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.ListView;

public class AdminView extends Activity implements OnItemClickListener{
	
	ListView lv;
	ArrayList<User> list = new ArrayList<User>();
	AdminAdapter adapter;
	Mydatabase database;
	AdapterView.AdapterContextMenuInfo info;
	String lname, fname, sex;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		this.setContentView(R.layout.admin_layout);
		
		lv = (ListView) this.findViewById(R.id.listView1);
		database = new Mydatabase(this);
		list = this.database.getList();
		adapter = new AdminAdapter(this, list);
		
		lv.setAdapter(adapter);
		lv.setOnItemClickListener(this);
		
		this.registerForContextMenu(lv);
		
		
	
	}
	@Override
	public void onItemClick(AdapterView<?> arg0, View arg1, int arg2, long arg3) {
		// TODO Auto-generated method stub
		
		/*String lname = arg0.getItemAtPosition(arg2).toString();
		String fname = arg0.getItemAtPosition(arg2).toString();
		String sex = arg0.getItemAtPosition(arg2).toString();
		
		/*AlertDialog.Builder builder = new AlertDialog.Builder(this);
		builder.setTitle(lname+" "+fname)
				.setView(view)*/
		
	}
	@Override
	public void onCreateContextMenu(ContextMenu menu, View v,
			ContextMenuInfo menuInfo) {
		// TODO Auto-generated method stub
		this.getMenuInflater().inflate(R.menu.admin_menu, menu);
		super.onCreateContextMenu(menu, v, menuInfo);
		
		info = (AdapterContextMenuInfo) menuInfo;
		fname = list.get(info.position).getFname();
		lname = list.get(info.position).getLname();
		sex = list.get(info.position).getSex();
		menu.setHeaderTitle(lname);
	
	}
	@Override
	public boolean onContextItemSelected(MenuItem item) {
		// TODO Auto-generated method stub
		
		this.database.deleteUser(lname,fname,sex);
		list.remove(info.position);
		adapter.notifyDataSetChanged();
		return super.onContextItemSelected(item);
		
		
		
		
	}
	
	
	
	

}
