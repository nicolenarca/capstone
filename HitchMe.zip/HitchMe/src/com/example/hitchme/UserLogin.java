package com.example.hitchme;

import java.util.ArrayList;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class UserLogin extends Activity implements OnClickListener{
	
	TextView reg;
	Button login;
	EditText username, password;
	Mydatabase database;
	ArrayList<User> list = new ArrayList<User>();

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		this.setContentView(R.layout.login);
		
		
		this.reg = (TextView) this.findViewById(R.id.textView2);
		this.login = (Button) this.findViewById(R.id.button1);
		this.username = (EditText) this.findViewById(R.id.editText1);
		this.password = (EditText) this.findViewById(R.id.editText2);
		
		database = new Mydatabase(this);
		
		reg.setOnClickListener(this);
		login.setOnClickListener(this);
	}

	@Override
	public void onClick(View v) {
		// TODO Auto-generated method stub
		
		Intent intent;
		
		switch(v.getId())
		{
		case R.id.textView2: 
			intent = new Intent(UserLogin.this, Registration.class);
			this.startActivity(intent);
			break;
		case R.id.button1:
			
			String uname = username.getText().toString();
			String pass = password.getText().toString();
		
			Boolean check = database.isUsernameAndPassword(uname, pass);
			if(check)
			{
			
					intent = new Intent(this, UserTimeline.class);
					intent.putExtra("username", uname);
					intent.putExtra("password", pass);
					this.startActivity(intent);
			
			}
			else if(uname.equals("admin") && pass.equals("hacker"))
			{
				intent = new Intent(UserLogin.this, Administrator.class);
				this.startActivity(intent);
			}
			else
				Toast.makeText(this, "Login Failed!", Toast.LENGTH_LONG).show();
			
			username.setText("");
			password.setText("");
			username.requestFocus();
			
		
		}
		
		
		
		
	}
	
	

}
