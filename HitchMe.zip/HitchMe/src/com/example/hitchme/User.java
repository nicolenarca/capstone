package com.example.hitchme;

public class User {
	
	String lname, fname, username, password, address, contactno, alternate, sex;
	int image;

	public User(String lname, String fname, String username, String password, String address, String contactno, String alternate, String sex) {
		super();
		this.lname = lname;
		this.fname = fname;
		this.username = username;
		this.password = password;
		this.address = address;
		this.contactno = contactno;
		this.alternate = alternate;
		this.sex = sex;
	}
	

	public String getLname() {
		return lname;
	}

	public void setLname(String lname) {
		this.lname = lname;
	}

	public String getFname() {
		return fname;
	}

	public void setFname(String fname) {
		this.fname = fname;
	}

	public String getContactno() {
		return contactno;
	}

	public void setContactno(String contactno) {
		this.contactno = contactno;
	}

	public String getSex() {
		return sex;
	}

	public void setSex(String sex) {
		this.sex = sex;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getAlternate() {
		return alternate;
	}

	public void setAlternate(String alternate) {
		this.alternate = alternate;
	}
	
}
